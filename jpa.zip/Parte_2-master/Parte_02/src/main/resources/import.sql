--insert into aluno (id, nome, media_notas) values (1, 'Ana', 10);
--insert into aluno (id, nome, media_notas) values (2, 'Maria', 3);
--insert into aluno (id, nome, media_notas) values (3, 'Ricardo', 7);

insert into tempo (id, dia, Min, Max, ar, tex, lat, lon, dat, hor) values (1, 'Quarta', 77, 774, 87, 'dia quente', 36, 21, 3,'04/01/2019', 11.45);
insert into tempo (id, dia, Min, Max, ar, tex, lat, lon, dat, hor) values (2, 'Quinta', 33, 999, 66, 'dia frio', 88, 44, 8, '10/11/2019', 12.23);
insert into tempo (id, dia, Min, Max, ar, tex, lat, lon, dat, hor) values (3, 'Sexta', 1, 774, 77, 'dia morno', 11, 33, 5, '14/12/2019', 14.45);
